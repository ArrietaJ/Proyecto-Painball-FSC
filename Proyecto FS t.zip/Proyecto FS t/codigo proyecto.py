import winsound
import threading
from tkinter import *
import tkinter as tk
import os
import random

# Variables globales
sonido_reproduciendo = True
jugador = 1
current_index = 1  # Índice para la animación

# Función para cargar imágenes
def cargardocumento(nombre):
    ruta = os.path.join("recursos", nombre)
    return tk.PhotoImage(file=ruta)

# Función para la animación de selección de jugador
def mostrar_animacion():
    global current_index, root, label

    root = tk.Toplevel()
    root.title("Animación de Selección")
    label = tk.Label(root)
    label.pack()
    current_index = 1
    actualizar_frame()

# Actualiza cada cuadro de la animación
def actualizar_frame():
    global current_index

    gif_name = f"animacion {current_index}.gif"
    img = cargardocumento(gif_name)
    label.config(image=img)
    label.image = img

    current_index += 1
    if current_index <= 28:
        root.after(80, actualizar_frame)  # Velocidad de la animación
    else:
        root.destroy()
        elegir_jugador_al_azar()

# Función para elegir jugador al azar y mostrar el resultado
def elegir_jugador_al_azar():
    resultado = random.choice(["Jugador 1", "Jugador 2"])
    new_window = tk.Toplevel()
    new_window.title("Jugador al Azar")
    tk.Label(new_window, text=f"El jugador inicial es: {resultado}", font=("Arial", 16)).pack(pady=20)

# Función para la configuración inicial
def configuracion():
    global ventana
    ventana.destroy()
    ventana = tk.Tk()
    ventana.title("Configuración Inicial")
    ventana.minsize(480, 360)
    ventana.resizable(width=False, height=False)
    
    tk.Label(ventana, text="Cantidad de Jugadores").place(x=175, y=0)
    tk.Label(ventana, text="1").place(x=150, y=20)
    tk.Label(ventana, text="2").place(x=300, y=20)

    boton1jugador = tk.Button(ventana, width=5, height=2, text="Aceptar", command=lambda: seleccionar_jugador(1))
    boton1jugador.place(x=130, y=60)
    boton2jugador = tk.Button(ventana, width=5, height=2, text="Aceptar", command=lambda: seleccionar_jugador(2))
    boton2jugador.place(x=275, y=60)
    tk.Button(ventana, text="Regresar", command=regresar).place(x=430, y=330)
    ventana.mainloop()

# Función para seleccionar jugador
def seleccionar_jugador(jugador_seleccionado):
    global jugador
    jugador = jugador_seleccionado
    regresar()

# Función principal
def principal():
    global ventana, sonido_reproduciendo
    ventana = tk.Tk()
    ventana.title("Pinball")
    ventana.minsize(480, 360)
    ventana.resizable(width=False, height=False)

    tk.Label(ventana, text="Pinball").place(x=200, y=0)
    tk.Button(ventana, text="About", command=informacion).place(x=200, y=60)
    tk.Button(ventana, text="Configuración Inicial", command=configuracion).place(x=160, y=100)
    tk.Button(ventana, text="Inicio de Juego", command=unjugador if jugador == 1 else dosjugador).place(x=175, y=140)
    tk.Button(ventana, text="Elegir Jugador al Azar", command=mostrar_animacion).place(x=175, y=180)

    threading.Thread(target=winsound.PlaySound, args=("musicafondo.wav", winsound.SND_LOOP | winsound.SND_ASYNC), daemon=True).start()
    tk.Button(ventana, text="Pausar Sonido", command=toggle_sonido).place(x=400, y=330)
    
    ventana.mainloop()

# Función para mostrar información
def informacion():
    global ventana
    ventana.destroy()
    ventana=Tk()
    ventana.minsize(1300,800)
    labelname=Label(ventana,text="Nombre de programador1:Anderson Lu Lu").place(x=0,y=40)
    labelcarnet=Label(ventana,text="carnet:2024222232").place(x=0,y=60)
    labelcurso=Label(ventana,text="Nombre de curso:Fundamentos De Sistemas Computacionales").place(x=450,y=20)
    labelU=Label(ventana,text="Instituto Tecnologica de Costa Rica").place(x=500,y=0)
    labelprofesor=Label(ventana,text="Nombre de profesor:Luis Alberto Chavarria Zamora ").place(x=475,y=40)
    labelfoto=Label(ventana,text="imagen de programador").place(x=0,y=120)
    
    imagenprogra=cargardocumento("anderson.gif")
    labelimagenprogra=Label(ventana,image=imagenprogra,width=500,height=600).place(x=0,y=140)
    labelcantante=Label(ventana,text="nombre de programador2: Julian Arrieta").place(x=950,y=40)
    labelgenero=Label(ventana,text="carnet:2022116242").place(x=950,y=60)
    labelfotosinger=Label(ventana,text="foto de programador2").place(x=950,y=120)
    imagenJulian=cargardocumento("Julian.gif")
    labelimagenJulian=Label(ventana,image=imagenJulian,width=500,height=600).place(x=800,y=140)
    buttonregresar=Button(ventana, text="regresar",command=regresar).place(x=1200,y=700)
    ventana.mainloop()

# Función para regresar al menú principal
def regresar():
    global ventana
    ventana.destroy()
    principal()

# Función para iniciar juego con un jugador
def unjugador():
    # Configuración y selección de personaje para un jugador
    pass

# Función para iniciar juego con dos jugadores
def dosjugador():
    # Configuración y selección de personaje para dos jugadores
    pass

# Función para pausar y reanudar el sonido
def toggle_sonido():
    global sonido_reproduciendo
    if sonido_reproduciendo:
        winsound.PlaySound(None, winsound.SND_PURGE)
        sonido_reproduciendo = False
    else:
        winsound.PlaySound("musicafondo.wav", winsound.SND_LOOP | winsound.SND_ASYNC)
        sonido_reproduciendo = True

principal()
