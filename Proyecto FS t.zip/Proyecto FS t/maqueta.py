import machine
import utime

# Configurar los pines de las zonas de anotación como entradas con resistencia pull-down
zona_1 = machine.Pin(20, machine.Pin.IN, machine.Pin.PULL_DOWN)
zona_2 = machine.Pin(19, machine.Pin.IN, machine.Pin.PULL_DOWN)
zona_3 = machine.Pin(16, machine.Pin.IN, machine.Pin.PULL_DOWN)
zona_4 = machine.Pin(17, machine.Pin.IN, machine.Pin.PULL_DOWN)
zona_5 = machine.Pin(18, machine.Pin.IN, machine.Pin.PULL_DOWN)

# Configurar los pines de los LEDs como salidas
led_1 = machine.Pin(15, machine.Pin.OUT)
led_2 = machine.Pin(14, machine.Pin.OUT)
led_3 = machine.Pin(13, machine.Pin.OUT)
led_4 = machine.Pin(12, machine.Pin.OUT)
led_5 = machine.Pin(11, machine.Pin.OUT)

while True:
    # Zona 1
    if zona_1.value() == 1:
        print('zona 1')
        led_1.value(1)  # Enciende el LED 1 si el circuito de la zona 1 está cerrado
    else:
        led_1.value(0)  # Apaga el LED 1 si el circuito de la zona 1 está abierto

    # Zona 2
    if zona_2.value() == 1:
        print('zona 2')
        led_2.value(1)
    else:
        led_2.value(0)

    # Zona 3
    if zona_3.value() == 1:
        print('zona 3')
        led_3.value(1)
    else:
        led_3.value(0)

    # Zona 4
    if zona_4.value() == 1:
        print('zona 4')
        led_4.value(1)
    else:
        led_4.value(0)

    # Zona 5 - LED con patrón de parpadeo
    if zona_5.value() == 1:
        print('zona 5')
        led_5.value(1)
        utime.sleep(0.5)
        led_5.value(0)
        utime.sleep(0.5)
    else:
        led_5.value(0)  # Apaga el LED 5 si el circuito de la zona 5 está abierto

    utime.sleep(1)  # Espera un segundo antes de repetir el ciclo
